# World Wide Défis
## Made by EpiCodifyCrew

## Application realisé avec React Js
## Features

- Switcher la langue depuis l’interface
- les langues : FR , US 

## Installation
```sh
- git clone https://github.com/ayubhr/w0rldW2021.git
- cd w0rldW2021
- yarn install
- yarn start
- naviguer sur http://localhost:3000
```


## Comment notre application fonctionne
    
    Ona utiliser une fichier JSON pour switcher la langue 


**Merci**

 
